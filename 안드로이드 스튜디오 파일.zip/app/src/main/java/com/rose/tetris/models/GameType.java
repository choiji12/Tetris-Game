package com.rose.tetris.models;

public enum GameType {
    TETRIS
}
